# Support

First, read the [Getting Started](GETTING_STARTED.md) guide and see the [Troubleshooting](TROUBLESHOOTING.md) guide. You might also check and see if there are any [existing issues](../../../issues?utf8=✓&q=is%3Aissue) that are helpful to you. If those don't help and you, create a new [issue](../../../issues).

Please do not email the author directly with questions.
