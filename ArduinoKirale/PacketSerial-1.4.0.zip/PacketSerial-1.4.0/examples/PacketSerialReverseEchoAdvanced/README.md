# Note

This example will not compile on boards that don't support `SoftwareSerial`. This includes DUE, Zero, etc.

That said, the concept of setting a custom `Stream` output will apply to any `Stream` supported by those boards.
