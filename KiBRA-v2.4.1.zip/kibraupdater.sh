#!/bin/bash
# Bash script to upgrade KiBRA package in KTBRN1 device.
IMAGEN_RO=/aufs/ro
IMAGEN_RW=

if [ -d $IMAGEN_RO ]
then
    PREFIX=$IMAGEN_RO
else
    PREFIX=$IMAGEN_RW
fi

# Python3 environment
PY3ENV=$PREFIX/opt/kirale/py3env

# Python2 environment
PY2ENV=$PREFIX/opt/kirale/py2env

if [ -d $PY3ENV ]
then
    if [ -d $PY2ENV ]
    then
        # Stop KiBRA service
        service kibra stop

        # Upgrade KiBRA package
        rm -rf /opt/kirale/kibra.cfg
        rm -rf "$PREFIX"/opt/kirale/kibra.cfg
        rm -rf "$PY3ENV"/lib/python3.7/site-packages/kibra*
        source "$PY3ENV"/bin/activate
        pip install --prefix "$PY3ENV" --no-warn-script-location ./kibra*.whl 
        deactivate

        # Upgrade KiTools package
        current_version=$(grep -o -P "(?<=__version__ = ').*(?=')" /opt/kirale/py3env/lib/python3.7/site-packages/kitools/__init__.py)
        new_version="1.4.0"
        if [ "$(printf '%s\n' "$new_version" "$current_version" | sort -V | head -n1)" = "$new_version" ]
        then
            :
        else
            rm -rf /opt/kirale/py3env/lib/python3.7/site-packages/kitools*
            rm -rf "$PY3ENV"/lib/python3.7/site-packages/kitools*
            source "$PY3ENV"/bin/activate
            pip install --prefix "$PY3ENV" --no-warn-script-location ./kitools*.whl
            deactivate
        fi

        # Upgrade WebAdmin package
        rm -rf "$PY2ENV"/lib/python2.7/site-packages/ajenti.plugin.branding*
        rm -rf "$PY2ENV"/lib/python2.7/site-packages/ajenti_plugin_branding
        rm -rf "$PY2ENV"/lib/python2.7/site-packages/ajenti.plugin.kibra*
        rm -rf "$PY2ENV"/lib/python2.7/site-packages/ajenti_plugin_kibra
        rm -rf "$PY2ENV"/lib/python2.7/site-packages/ajenti.plugin.network*
        rm -rf "$PY2ENV"/lib/python2.7/site-packages/ajenti_plugin_network
        source "$PY2ENV"/bin/activate
        pip install --prefix "$PY2ENV" --no-warn-script-location ./ajenti.plugin.*.whl 
        deactivate

        # Patches
        # Fix radvd.service
        FILE_RADVD=/lib/systemd/system/radvd.service
        if grep -q 'PIDFile=/var/run/radvd.pid' "$FILE_RADVD"
        then
            sed -i '/PIDFile=/c PIDFile=/run/radvd.pid' "$IMAGEN_RO$FILE_RADVD"
        fi
    else
        echo "This is not a valid image to install KiBRA"
        exit 1
    fi
else
    echo "This is not a valid image to install KiBRA"
    exit 1
fi
