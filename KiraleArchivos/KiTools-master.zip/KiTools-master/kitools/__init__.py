'''Kirale Serial utilities'''

__version__ = '1.4.0'
